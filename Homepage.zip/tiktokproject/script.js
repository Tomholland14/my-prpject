
const toggleButtons = document.querySelectorAll(".toggle-btn");

toggleButtons.forEach((btn) => {
    btn.addEventListener("click", (e) => {
        e.preventDefault(); // Prevent default link behavior
        const submenu = btn.nextElementSibling;

        if (submenu) {
            submenu.style.display = submenu.style.display === "block" ? "none" : "block";
        }
    });
});